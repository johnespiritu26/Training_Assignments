package com.myapp.model;

public class Product {
	
	private int productId;
	private String prodName;
	private float prodPrice;
	
	public Product() {
		
	}

	public Product(int productId, String prodName, float prodPrice) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(float prodPrice) {
		this.prodPrice = prodPrice;
	}
	
}
