--insert admins

insert into admins(email, password)  values('casanobav@gmail.com', 'atos1234');
insert into admins(email, password)  values('miggyvivo@yahoo.com', 'atos1234');
insert into admins(email, password)  values('tymartsberganio@gmail.com', 'atos1234');
insert into admins(email, password)  values('khevin.jacang10@gmail.com', 'atos1234');
insert into admins(email, password)  values('emmanueljosephellaga@gmail.com', 'atos1234');
insert into admins(email, password)  values('jhayabayon18@gmail.com', 'atos1234');
insert into admins(email, password)  values('moncadachristianm@gmail.com', 'atos1234');
insert into admins(email, password)  values('remojared@gmail.com', 'atos1234');
insert into admins(email, password)  values('jpcon45@gmail.com', 'atos1234');
insert into admins(email, password)  values('martinelidantes232@gmail.com', 'atos1234');
insert into admins(email, password)  values('johnespiritu26@gmail.com', 'atos1234');

--insert categories

insert into categories(category_id, category_name) VALUES (00001, 'Electronics');
insert into categories(category_id, category_name) VALUES (00002, 'Clothing');
insert into categories(category_id, category_name) VALUES (00003, 'Home');
insert into categories(category_id, category_name) VALUES (00004, 'Entertainment');
insert into categories(category_id, category_name) VALUES (00005, 'Family');
insert into categories(category_id, category_name) VALUES (00006, 'Garage');
insert into categories(category_id, category_name) VALUES (00007, 'Beauty');
insert into categories(category_id, category_name) VALUES (00008, 'Animals');
insert into categories(category_id, category_name) VALUES (00009, 'Food');
insert into categories(category_id, category_name) VALUES (00010, 'Kitchen');

--insert products

insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00001, 'Samsung Galaxy S20 Ultra 5G', 00001, 40000, 'samsung.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00002, 'White T-shirt', 00002, 500, 'white.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00003, 'Sofa', 00003, 25000, 'sofa.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00004, 'Sony OLED TV 4K 75in', 00004, 50000, 'sony.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00005, 'Play Pen', 00005, 10000, 'play.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00006, 'Toyota Supra 2022', 00006, 5000000, 'toyota.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00007, 'VIce 001', 00007, 700, 'vice.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00008, 'Dog leash', 00008, 500, 'dog.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00009, 'Rebisco', 00009, 100, 'rebisco.jpg', 10);
insert into products(product_id, product_name, category_id, product_price, product_image, product_available_qty) values(00010, 'Induction Cooker', 00010, 7000, 'induction.jpg', 10);






